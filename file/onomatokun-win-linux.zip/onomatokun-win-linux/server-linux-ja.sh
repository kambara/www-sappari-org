#!/bin/sh

JULIUS='grammar-kit-v4.2-linux'
ONOMATOPE='onomatope-ja'

./$JULIUS/bin/julius-4.2 -input mic -C $ONOMATOPE/mic.jconf -C $JULIUS/hmm_ptm.jconf -module
