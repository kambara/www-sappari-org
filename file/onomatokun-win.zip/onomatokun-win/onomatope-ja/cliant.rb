#!/usr/bin/ruby

require 'socket'

port = if ARGV.size > 0 then ARGV.shift else 10500 end
puts "port #{port}"

s = TCPSocket.open("localhost", port)

while str = s.gets
  puts str
end

s.close
