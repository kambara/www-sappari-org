/*
 * Created by SharpDevelop.
 * User: kambara
 * Date: 2004/10/26
 * Time: 21:56
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.Drawing;
using System.Windows.Forms;

namespace AlbumMaker
{
	/// <summary>
	/// Description of ProcessForm.
	/// </summary>
	public class ProgressForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ProgressBar progressBar1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label stateLabel;
		private System.Windows.Forms.ProgressBar totalProgressBar;
		public ProgressForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		#region Windows Forms Designer generated code
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent() {
			this.totalProgressBar = new System.Windows.Forms.ProgressBar();
			this.stateLabel = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.progressBar1 = new System.Windows.Forms.ProgressBar();
			this.SuspendLayout();
			// 
			// totalProgressBar
			// 
			this.totalProgressBar.Location = new System.Drawing.Point(16, 80);
			this.totalProgressBar.Name = "totalProgressBar";
			this.totalProgressBar.Size = new System.Drawing.Size(280, 23);
			this.totalProgressBar.TabIndex = 1;
			// 
			// stateLabel
			// 
			this.stateLabel.Location = new System.Drawing.Point(16, 8);
			this.stateLabel.Name = "stateLabel";
			this.stateLabel.Size = new System.Drawing.Size(280, 16);
			this.stateLabel.TabIndex = 2;
			this.stateLabel.Text = "サムネイル作成";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(120, 112);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(80, 23);
			this.button1.TabIndex = 4;
			this.button1.Text = "中止";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 64);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(280, 16);
			this.label1.TabIndex = 3;
			this.label1.Text = "全体の進捗";
			// 
			// progressBar1
			// 
			this.progressBar1.Location = new System.Drawing.Point(16, 24);
			this.progressBar1.Name = "progressBar1";
			this.progressBar1.Size = new System.Drawing.Size(280, 23);
			this.progressBar1.TabIndex = 0;
			// 
			// ProcessForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 12);
			this.ClientSize = new System.Drawing.Size(312, 142);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.stateLabel);
			this.Controls.Add(this.totalProgressBar);
			this.Controls.Add(this.progressBar1);
			this.Name = "ProcessForm";
			this.Text = "アルバム作成中";
			this.ResumeLayout(false);
		}
		#endregion
	}
}
