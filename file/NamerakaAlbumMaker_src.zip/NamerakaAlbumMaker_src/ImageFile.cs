/*
 * Created by SharpDevelop.
 * User: kambara
 * Date: 2004/10/25
 * Time: 0:34
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;

namespace AlbumMaker
{
	/// <summary>
	/// Description of ImageFile.
	/// </summary>
	public class ImageFile
	{
		private string name = "";
		private string path = "";
		
		public ImageFile(string path)
		{
			this.path = path;
			this.name = System.IO.Path.GetFileName(path);
		}
		
		public override string ToString(){
			return this.name;
		}
		
		public string Name{
			get{
				return this.name;
			}
		}
		
		public string Path{
			get{
				return this.path;
			}
		}
	}
}
