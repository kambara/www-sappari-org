/*
 * Created by SharpDevelop.
 * User: kambara
 * Date: 2004/10/26
 * Time: 22:13
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.Drawing;
using System.Windows.Forms;

namespace AlbumMaker
{
	/// <summary>
	/// Description of ProgressForm.
	/// </summary>
	public class ProgressForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.CheckBox openBrowserCheckBox;
		private System.Windows.Forms.Label stateLabel;
		private System.Windows.Forms.Button stopButton;
		private System.Windows.Forms.ProgressBar totalProgressBar;

		public ProgressForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		#region Windows Forms Designer generated code
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent() {
			this.totalProgressBar = new System.Windows.Forms.ProgressBar();
			this.stopButton = new System.Windows.Forms.Button();
			this.stateLabel = new System.Windows.Forms.Label();
			this.openBrowserCheckBox = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// totalProgressBar
			// 
			this.totalProgressBar.Location = new System.Drawing.Point(16, 32);
			this.totalProgressBar.Name = "totalProgressBar";
			this.totalProgressBar.Size = new System.Drawing.Size(256, 16);
			this.totalProgressBar.TabIndex = 1;
			// 
			// stopButton
			// 
			this.stopButton.DialogResult = System.Windows.Forms.DialogResult.Abort;
			this.stopButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.stopButton.Location = new System.Drawing.Point(192, 56);
			this.stopButton.Name = "stopButton";
			this.stopButton.Size = new System.Drawing.Size(80, 23);
			this.stopButton.TabIndex = 4;
			this.stopButton.Text = "中止";
			// 
			// stateLabel
			// 
			this.stateLabel.Location = new System.Drawing.Point(16, 0);
			this.stateLabel.Name = "stateLabel";
			this.stateLabel.Size = new System.Drawing.Size(256, 32);
			this.stateLabel.TabIndex = 2;
			this.stateLabel.Text = "作成中";
			this.stateLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// openBrowserCheckBox
			// 
			this.openBrowserCheckBox.Checked = true;
			this.openBrowserCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.openBrowserCheckBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.openBrowserCheckBox.Location = new System.Drawing.Point(16, 56);
			this.openBrowserCheckBox.Name = "openBrowserCheckBox";
			this.openBrowserCheckBox.Size = new System.Drawing.Size(128, 24);
			this.openBrowserCheckBox.TabIndex = 5;
			this.openBrowserCheckBox.Text = "アルバムを開く";
			// 
			// ProgressForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 12);
			this.ClientSize = new System.Drawing.Size(288, 88);
			this.ControlBox = false;
			this.Controls.Add(this.openBrowserCheckBox);
			this.Controls.Add(this.stopButton);
			this.Controls.Add(this.stateLabel);
			this.Controls.Add(this.totalProgressBar);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ProgressForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "アルバムを作成中";
			this.ResumeLayout(false);
		}
		#endregion
		
		public void setStatus(string s){
			this.stateLabel.Text = s;
		}
		
		public void setTotalProgress(int v){
			this.totalProgressBar.Value = v;
		}
		
		public void setTotalProgressMax(int m){
			this.totalProgressBar.Maximum = m;
		}
		
		public void complete(){
			this.Text = "アルバムが作成されました";
			this.stateLabel.Text = "完了";
			this.stopButton.DialogResult = DialogResult.OK;
			this.stopButton.Text = "OK";
		}
		
		public bool openBrowserCheck(){
			return this.openBrowserCheckBox.Checked;
		}
	}
}
