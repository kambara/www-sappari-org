/*
 * Created by SharpDevelop.
 * User: kambara
 * Date: 2004/10/20
 * Time: 12:58
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Text.RegularExpressions;

namespace AlbumMaker
{
	/// <summary>
	/// Description of MainForm.	
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.ListBox imageListBox;
		private System.Windows.Forms.Button addFileButton;
		private System.Windows.Forms.Panel scrollbarColorPanel;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.PictureBox preview;
		private System.Windows.Forms.Button generateAlbumButton;
		private System.Windows.Forms.Button saveFolderButton;
		private System.Windows.Forms.FolderBrowserDialog imageFolderDialog;
		private System.Windows.Forms.NumericUpDown imageBorderWidthBox;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel bgColorPanel;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Panel arrowColorPanel;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Button clearListButton;
		private System.Windows.Forms.NumericUpDown thumbHeightBox;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.CheckBox originalImageCheckBox;
		private System.Windows.Forms.LinkLabel previewLinkLabel;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Panel scrollBorderColorPanel;
		private System.Windows.Forms.Button clearSelectedFileButton;
		private System.Windows.Forms.OpenFileDialog imageFileDialog;
		private System.Windows.Forms.Panel imageBorderColorPanel;
		private System.Windows.Forms.ColorDialog colorDialog;
		private System.Windows.Forms.TextBox saveFolderTextBox;
		private System.Windows.Forms.NumericUpDown imageSizeBox;
		private System.Windows.Forms.LinkLabel albumFolderLinkLabel;
		private System.Windows.Forms.TextBox albumTitleTextBox;
		private System.Windows.Forms.FolderBrowserDialog albumFolderDialog;
		private System.Windows.Forms.Label label3;
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			this.initAlbumConfig();
			this.saveFolderTextBox.Text = System.Environment.GetFolderPath(
			                                      Environment.SpecialFolder.DesktopDirectory);
			this.changeAlbumFolderLink();
		}
		
		[STAThread]
		public static void Main(string[] args)
		{
			Application.Run(new MainForm());
		}
		
		#region Windows Forms Designer generated code
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent() {
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			this.label3 = new System.Windows.Forms.Label();
			this.albumFolderDialog = new System.Windows.Forms.FolderBrowserDialog();
			this.albumTitleTextBox = new System.Windows.Forms.TextBox();
			this.albumFolderLinkLabel = new System.Windows.Forms.LinkLabel();
			this.imageSizeBox = new System.Windows.Forms.NumericUpDown();
			this.saveFolderTextBox = new System.Windows.Forms.TextBox();
			this.colorDialog = new System.Windows.Forms.ColorDialog();
			this.imageBorderColorPanel = new System.Windows.Forms.Panel();
			this.imageFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.clearSelectedFileButton = new System.Windows.Forms.Button();
			this.scrollBorderColorPanel = new System.Windows.Forms.Panel();
			this.label11 = new System.Windows.Forms.Label();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.label14 = new System.Windows.Forms.Label();
			this.previewLinkLabel = new System.Windows.Forms.LinkLabel();
			this.originalImageCheckBox = new System.Windows.Forms.CheckBox();
			this.label10 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.thumbHeightBox = new System.Windows.Forms.NumericUpDown();
			this.clearListButton = new System.Windows.Forms.Button();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.arrowColorPanel = new System.Windows.Forms.Panel();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.bgColorPanel = new System.Windows.Forms.Panel();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.imageBorderWidthBox = new System.Windows.Forms.NumericUpDown();
			this.imageFolderDialog = new System.Windows.Forms.FolderBrowserDialog();
			this.saveFolderButton = new System.Windows.Forms.Button();
			this.generateAlbumButton = new System.Windows.Forms.Button();
			this.preview = new System.Windows.Forms.PictureBox();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.scrollbarColorPanel = new System.Windows.Forms.Panel();
			this.addFileButton = new System.Windows.Forms.Button();
			this.imageListBox = new System.Windows.Forms.ListBox();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			((System.ComponentModel.ISupportInitialize)(this.imageSizeBox)).BeginInit();
			this.tabPage2.SuspendLayout();
			this.tabControl1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.thumbHeightBox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.imageBorderWidthBox)).BeginInit();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.SuspendLayout();
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 96);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(216, 16);
			this.label3.TabIndex = 11;
			this.label3.Text = "次の位置にアルバムフォルダが作成されます";
			// 
			// albumFolderDialog
			// 
			this.albumFolderDialog.Description = "アルバムを保存するフォルダを選んでください";
			// 
			// albumTitleTextBox
			// 
			this.albumTitleTextBox.Location = new System.Drawing.Point(72, 8);
			this.albumTitleTextBox.Name = "albumTitleTextBox";
			this.albumTitleTextBox.Size = new System.Drawing.Size(160, 19);
			this.albumTitleTextBox.TabIndex = 9;
			this.albumTitleTextBox.Text = "なめらかアルバム";
			this.albumTitleTextBox.TextChanged += new System.EventHandler(this.AlbumTitleTextBoxTextChanged);
			// 
			// albumFolderLinkLabel
			// 
			this.albumFolderLinkLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.albumFolderLinkLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.albumFolderLinkLabel.Location = new System.Drawing.Point(24, 120);
			this.albumFolderLinkLabel.Name = "albumFolderLinkLabel";
			this.albumFolderLinkLabel.Size = new System.Drawing.Size(272, 80);
			this.albumFolderLinkLabel.TabIndex = 8;
			this.albumFolderLinkLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.AlbumFolderLinkLabelLinkClicked);
			// 
			// imageSizeBox
			// 
			this.imageSizeBox.Location = new System.Drawing.Point(104, 30);
			this.imageSizeBox.Name = "imageSizeBox";
			this.imageSizeBox.Size = new System.Drawing.Size(48, 19);
			this.imageSizeBox.TabIndex = 16;
			this.imageSizeBox.Value = new System.Decimal(new int[] {
						80,
						0,
						0,
						0});
			// 
			// saveFolderTextBox
			// 
			this.saveFolderTextBox.Location = new System.Drawing.Point(72, 32);
			this.saveFolderTextBox.Name = "saveFolderTextBox";
			this.saveFolderTextBox.Size = new System.Drawing.Size(160, 19);
			this.saveFolderTextBox.TabIndex = 5;
			this.saveFolderTextBox.Text = "";
			this.saveFolderTextBox.TextChanged += new System.EventHandler(this.SaveFolderTextBoxTextChanged);
			// 
			// imageBorderColorPanel
			// 
			this.imageBorderColorPanel.BackColor = System.Drawing.Color.White;
			this.imageBorderColorPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.imageBorderColorPanel.Location = new System.Drawing.Point(104, 56);
			this.imageBorderColorPanel.Name = "imageBorderColorPanel";
			this.imageBorderColorPanel.Size = new System.Drawing.Size(32, 16);
			this.imageBorderColorPanel.TabIndex = 13;
			this.imageBorderColorPanel.Click += new System.EventHandler(this.ColorPanelClick);
			// 
			// imageFileDialog
			// 
			this.imageFileDialog.Filter = "Image Files (*.jpg; *.png; *.gif; *.bmp)|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
			this.imageFileDialog.Multiselect = true;
			// 
			// clearSelectedFileButton
			// 
			this.clearSelectedFileButton.Enabled = false;
			this.clearSelectedFileButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.clearSelectedFileButton.Location = new System.Drawing.Point(152, 80);
			this.clearSelectedFileButton.Name = "clearSelectedFileButton";
			this.clearSelectedFileButton.Size = new System.Drawing.Size(144, 23);
			this.clearSelectedFileButton.TabIndex = 2;
			this.clearSelectedFileButton.Text = "選択したファイルをクリア";
			this.clearSelectedFileButton.Click += new System.EventHandler(this.ClearSelectedFileButtonClick);
			// 
			// scrollBorderColorPanel
			// 
			this.scrollBorderColorPanel.BackColor = System.Drawing.Color.White;
			this.scrollBorderColorPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.scrollBorderColorPanel.Location = new System.Drawing.Point(104, 128);
			this.scrollBorderColorPanel.Name = "scrollBorderColorPanel";
			this.scrollBorderColorPanel.Size = new System.Drawing.Size(32, 16);
			this.scrollBorderColorPanel.TabIndex = 12;
			this.scrollBorderColorPanel.Click += new System.EventHandler(this.ColorPanelClick);
			// 
			// label11
			// 
			this.label11.Location = new System.Drawing.Point(152, 80);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(24, 16);
			this.label11.TabIndex = 20;
			this.label11.Text = "px";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// tabPage2
			// 
			this.tabPage2.BackColor = System.Drawing.SystemColors.ControlLight;
			this.tabPage2.Controls.Add(this.label14);
			this.tabPage2.Controls.Add(this.label13);
			this.tabPage2.Controls.Add(this.thumbHeightBox);
			this.tabPage2.Controls.Add(this.button1);
			this.tabPage2.Controls.Add(this.label11);
			this.tabPage2.Controls.Add(this.label6);
			this.tabPage2.Controls.Add(this.label10);
			this.tabPage2.Controls.Add(this.imageBorderWidthBox);
			this.tabPage2.Controls.Add(this.imageSizeBox);
			this.tabPage2.Controls.Add(this.arrowColorPanel);
			this.tabPage2.Controls.Add(this.scrollbarColorPanel);
			this.tabPage2.Controls.Add(this.imageBorderColorPanel);
			this.tabPage2.Controls.Add(this.scrollBorderColorPanel);
			this.tabPage2.Controls.Add(this.bgColorPanel);
			this.tabPage2.Controls.Add(this.label12);
			this.tabPage2.Controls.Add(this.label9);
			this.tabPage2.Controls.Add(this.label8);
			this.tabPage2.Controls.Add(this.label7);
			this.tabPage2.Controls.Add(this.label5);
			this.tabPage2.Controls.Add(this.label4);
			this.tabPage2.Location = new System.Drawing.Point(4, 21);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Size = new System.Drawing.Size(304, 215);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "アルバムの設定";
			// 
			// label14
			// 
			this.label14.Location = new System.Drawing.Point(152, 176);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(24, 16);
			this.label14.TabIndex = 24;
			this.label14.Text = "px";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// previewLinkLabel
			// 
			this.previewLinkLabel.Enabled = false;
			this.previewLinkLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.previewLinkLabel.Location = new System.Drawing.Point(496, 280);
			this.previewLinkLabel.Name = "previewLinkLabel";
			this.previewLinkLabel.Size = new System.Drawing.Size(96, 32);
			this.previewLinkLabel.TabIndex = 10;
			this.previewLinkLabel.TabStop = true;
			this.previewLinkLabel.Text = "アルバムを見る";
			this.previewLinkLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.previewLinkLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.PreviewLinkLabelLinkClicked);
			// 
			// originalImageCheckBox
			// 
			this.originalImageCheckBox.Checked = true;
			this.originalImageCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.originalImageCheckBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.originalImageCheckBox.Location = new System.Drawing.Point(72, 56);
			this.originalImageCheckBox.Name = "originalImageCheckBox";
			this.originalImageCheckBox.Size = new System.Drawing.Size(176, 24);
			this.originalImageCheckBox.TabIndex = 7;
			this.originalImageCheckBox.Text = "元の画像ファイルを含める";
			// 
			// label10
			// 
			this.label10.Location = new System.Drawing.Point(152, 32);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(24, 16);
			this.label10.TabIndex = 18;
			this.label10.Text = "%";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label13
			// 
			this.label13.Location = new System.Drawing.Point(16, 176);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(88, 16);
			this.label13.TabIndex = 23;
			this.label13.Text = "サムネイルの高さ";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label12
			// 
			this.label12.Location = new System.Drawing.Point(16, 128);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(80, 16);
			this.label12.TabIndex = 8;
			this.label12.Text = "スクロール枠線";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Location = new System.Drawing.Point(320, 24);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(312, 240);
			this.tabControl1.TabIndex = 13;
			// 
			// thumbHeightBox
			// 
			this.thumbHeightBox.Increment = new System.Decimal(new int[] {
						10,
						0,
						0,
						0});
			this.thumbHeightBox.Location = new System.Drawing.Point(104, 174);
			this.thumbHeightBox.Maximum = new System.Decimal(new int[] {
						800,
						0,
						0,
						0});
			this.thumbHeightBox.Name = "thumbHeightBox";
			this.thumbHeightBox.Size = new System.Drawing.Size(48, 19);
			this.thumbHeightBox.TabIndex = 22;
			this.thumbHeightBox.Value = new System.Decimal(new int[] {
						320,
						0,
						0,
						0});
			// 
			// clearListButton
			// 
			this.clearListButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.clearListButton.Location = new System.Drawing.Point(152, 104);
			this.clearListButton.Name = "clearListButton";
			this.clearListButton.Size = new System.Drawing.Size(144, 23);
			this.clearListButton.TabIndex = 3;
			this.clearListButton.Text = "すべてのファイルをクリア";
			this.clearListButton.Click += new System.EventHandler(this.ClearListButtonClick);
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(16, 152);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(80, 16);
			this.label8.TabIndex = 4;
			this.label8.Text = "矢印";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label9
			// 
			this.label9.Location = new System.Drawing.Point(16, 104);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(80, 16);
			this.label9.TabIndex = 5;
			this.label9.Text = "スクロールバー";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// arrowColorPanel
			// 
			this.arrowColorPanel.BackColor = System.Drawing.Color.White;
			this.arrowColorPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.arrowColorPanel.Location = new System.Drawing.Point(104, 152);
			this.arrowColorPanel.Name = "arrowColorPanel";
			this.arrowColorPanel.Size = new System.Drawing.Size(32, 16);
			this.arrowColorPanel.TabIndex = 15;
			this.arrowColorPanel.Click += new System.EventHandler(this.ColorPanelClick);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(16, 32);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(80, 16);
			this.label4.TabIndex = 0;
			this.label4.Text = "写真の大きさ";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(16, 8);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(80, 16);
			this.label5.TabIndex = 1;
			this.label5.Text = "背景";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(64, 80);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(16, 16);
			this.label6.TabIndex = 19;
			this.label6.Text = "幅";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(16, 56);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(80, 16);
			this.label7.TabIndex = 3;
			this.label7.Text = "写真の枠線";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// bgColorPanel
			// 
			this.bgColorPanel.BackColor = System.Drawing.Color.White;
			this.bgColorPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.bgColorPanel.Location = new System.Drawing.Point(104, 8);
			this.bgColorPanel.Name = "bgColorPanel";
			this.bgColorPanel.Size = new System.Drawing.Size(32, 16);
			this.bgColorPanel.TabIndex = 11;
			this.bgColorPanel.Click += new System.EventHandler(this.ColorPanelClick);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 32);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(56, 16);
			this.label1.TabIndex = 10;
			this.label1.Text = "保存場所";
			this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(48, 16);
			this.label2.TabIndex = 11;
			this.label2.Text = "タイトル";
			this.label2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// imageBorderWidthBox
			// 
			this.imageBorderWidthBox.Location = new System.Drawing.Point(104, 78);
			this.imageBorderWidthBox.Maximum = new System.Decimal(new int[] {
						50,
						0,
						0,
						0});
			this.imageBorderWidthBox.Name = "imageBorderWidthBox";
			this.imageBorderWidthBox.Size = new System.Drawing.Size(48, 19);
			this.imageBorderWidthBox.TabIndex = 17;
			// 
			// imageFolderDialog
			// 
			this.imageFolderDialog.Description = "選択したフォルダ以下、全てのサブフォルダ内の画像が追加されます";
			this.imageFolderDialog.ShowNewFolderButton = false;
			// 
			// saveFolderButton
			// 
			this.saveFolderButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.saveFolderButton.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(128)));
			this.saveFolderButton.Location = new System.Drawing.Point(236, 31);
			this.saveFolderButton.Name = "saveFolderButton";
			this.saveFolderButton.Size = new System.Drawing.Size(60, 21);
			this.saveFolderButton.TabIndex = 6;
			this.saveFolderButton.Text = "選択";
			this.saveFolderButton.Click += new System.EventHandler(this.SaveFolderButtonClick);
			// 
			// generateAlbumButton
			// 
			this.generateAlbumButton.Enabled = false;
			this.generateAlbumButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.generateAlbumButton.Location = new System.Drawing.Point(344, 280);
			this.generateAlbumButton.Name = "generateAlbumButton";
			this.generateAlbumButton.Size = new System.Drawing.Size(136, 32);
			this.generateAlbumButton.TabIndex = 9;
			this.generateAlbumButton.Text = "アルバムを作成";
			this.generateAlbumButton.Click += new System.EventHandler(this.GenerateAlbumButtonClick);
			// 
			// preview
			// 
			this.preview.Location = new System.Drawing.Point(16, 16);
			this.preview.Name = "preview";
			this.preview.Size = new System.Drawing.Size(112, 112);
			this.preview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.preview.TabIndex = 19;
			this.preview.TabStop = false;
			// 
			// button1
			// 
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.button1.Location = new System.Drawing.Point(192, 184);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(104, 23);
			this.button1.TabIndex = 21;
			this.button1.Text = "デフォルトに戻す";
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// button2
			// 
			this.button2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.button2.Location = new System.Drawing.Point(152, 40);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(144, 23);
			this.button2.TabIndex = 21;
			this.button2.Text = "フォルダ以下を追加";
			this.button2.Click += new System.EventHandler(this.AddFolderButtonClick);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.button2);
			this.groupBox1.Controls.Add(this.groupBox2);
			this.groupBox1.Controls.Add(this.clearListButton);
			this.groupBox1.Controls.Add(this.clearSelectedFileButton);
			this.groupBox1.Controls.Add(this.addFileButton);
			this.groupBox1.Controls.Add(this.imageListBox);
			this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox1.Location = new System.Drawing.Point(8, 16);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(304, 304);
			this.groupBox1.TabIndex = 10;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "画像";
			// 
			// groupBox2
			// 
			this.groupBox2.BackColor = System.Drawing.SystemColors.Control;
			this.groupBox2.Controls.Add(this.preview);
			this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox2.Location = new System.Drawing.Point(152, 160);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(144, 136);
			this.groupBox2.TabIndex = 20;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "プレビュー";
			// 
			// scrollbarColorPanel
			// 
			this.scrollbarColorPanel.BackColor = System.Drawing.Color.White;
			this.scrollbarColorPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.scrollbarColorPanel.Location = new System.Drawing.Point(104, 104);
			this.scrollbarColorPanel.Name = "scrollbarColorPanel";
			this.scrollbarColorPanel.Size = new System.Drawing.Size(32, 16);
			this.scrollbarColorPanel.TabIndex = 14;
			this.scrollbarColorPanel.Click += new System.EventHandler(this.ColorPanelClick);
			// 
			// addFileButton
			// 
			this.addFileButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.addFileButton.Location = new System.Drawing.Point(152, 16);
			this.addFileButton.Name = "addFileButton";
			this.addFileButton.Size = new System.Drawing.Size(144, 23);
			this.addFileButton.TabIndex = 0;
			this.addFileButton.Text = "ファイルを追加";
			this.addFileButton.Click += new System.EventHandler(this.AddFileButtonClick);
			// 
			// imageListBox
			// 
			this.imageListBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
						| System.Windows.Forms.AnchorStyles.Left)));
			this.imageListBox.ItemHeight = 12;
			this.imageListBox.Location = new System.Drawing.Point(8, 16);
			this.imageListBox.Name = "imageListBox";
			this.imageListBox.Size = new System.Drawing.Size(136, 280);
			this.imageListBox.TabIndex = 11;
			this.imageListBox.TabStop = false;
			this.imageListBox.SelectedIndexChanged += new System.EventHandler(this.ImageListBoxSelectedIndexChanged);
			// 
			// tabPage1
			// 
			this.tabPage1.BackColor = System.Drawing.SystemColors.ControlLight;
			this.tabPage1.Controls.Add(this.label2);
			this.tabPage1.Controls.Add(this.saveFolderTextBox);
			this.tabPage1.Controls.Add(this.label1);
			this.tabPage1.Controls.Add(this.saveFolderButton);
			this.tabPage1.Controls.Add(this.albumTitleTextBox);
			this.tabPage1.Controls.Add(this.originalImageCheckBox);
			this.tabPage1.Controls.Add(this.label3);
			this.tabPage1.Controls.Add(this.albumFolderLinkLabel);
			this.tabPage1.Location = new System.Drawing.Point(4, 21);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Size = new System.Drawing.Size(304, 215);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "基本";
			// 
			// MainForm
			// 
			this.AllowDrop = true;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 12);
			this.ClientSize = new System.Drawing.Size(642, 328);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.previewLinkLabel);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.generateAlbumButton);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.Text = "なめらかアルバムメーカー";
			this.DragDrop += new System.Windows.Forms.DragEventHandler(this.MainFormDragDrop);
			this.DragEnter += new System.Windows.Forms.DragEventHandler(this.MainFormDragEnter);
			((System.ComponentModel.ISupportInitialize)(this.imageSizeBox)).EndInit();
			this.tabPage2.ResumeLayout(false);
			this.tabControl1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.thumbHeightBox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.imageBorderWidthBox)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		#endregion
		
		private bool IsImageFile(string path){
			// 拡張子をチェック
			string ext = Path.GetExtension(path);
			ext = ext.ToLower();
			if (ext==".jpg" || ext==".jpeg" || ext==".png" || ext==".gif" || ext==".bmp")
				return true;
			else
				return false;
		}
		
		private void addImageFile(string f){
			if (this.IsImageFile(f))
				this.imageListBox.Items.Add(new ImageFile(f));
		}
		
		private void addImageFiles(string[] files){
			foreach(string f in files){
				this.addImageFile(f);
			}
		}
		
		//
		// ファイル追加ボタンクリック
		//
		void AddFileButtonClick(object sender, System.EventArgs e)
		{
			if (this.imageFileDialog.ShowDialog() == DialogResult.OK){
				string[] files = this.imageFileDialog.FileNames;
				this.addImageFiles(files);
				this.checkGeneratable();
			}
		}
		
		//
		// フォルダ以下をすべて追加
		//
		private void addImageFromDirectory(string dirPath){
			if (Directory.Exists(dirPath)){
				string[] files = Directory.GetFiles(dirPath);
				this.addImageFiles(files);
				
				string[] dirs = Directory.GetDirectories(dirPath);
				foreach(string path in dirs){
					this.addImageFromDirectory(path);
				}
			}
		}
		
		//
		// フォルダから追加
		//
		void AddFolderButtonClick(object sender, System.EventArgs e)
		{
			if (this.imageFolderDialog.ShowDialog() == DialogResult.OK){
				string path = this.imageFolderDialog.SelectedPath;
				this.addImageFromDirectory(path);
				this.checkGeneratable();
			}
		}
		
		//
		// リストををクリア
		//
		void ClearListButtonClick(object sender, System.EventArgs e)
		{
			this.imageListBox.Items.Clear();
			this.clearSelectedFileButton.Enabled = false;
			this.preview.Image = null;
			this.checkGeneratable();
		}
		
		//
		// リスト選択時
		//
		void ImageListBoxSelectedIndexChanged(object sender, System.EventArgs e)
		{
			int index = this.imageListBox.SelectedIndex;
			if (index < 0) {
				this.clearSelectedFileButton.Enabled = false; // 何も選択していない
			}
			else {
				this.clearSelectedFileButton.Enabled = true;
				// プレビューを表示
				ImageFile imgfile = (ImageFile)this.imageListBox.SelectedItem;
				if (File.Exists(imgfile.Path)){
					try{
						Bitmap bmp = new Bitmap(imgfile.Path);
						int w = this.preview.Size.Width;
						int h = this.preview.Size.Height;
						if (bmp.Width>=bmp.Height){ // 横長
							h = (int)(bmp.Height * w / bmp.Width);
						} else { // 縦長
							w = (int)(bmp.Width * h / bmp.Height);
						}
						bmp = new Bitmap(bmp, w, h);
						this.preview.Image = bmp;
					}catch(Exception ex){
						MessageBox.Show(ex.Message);
					}
				}
			}
		}
		
		//
		// 選択したファイルをクリア
		//
		void ClearSelectedFileButtonClick(object sender, System.EventArgs e)
		{
			int index = this.imageListBox.SelectedIndex;
			if (index >= 0){
				this.imageListBox.Items.RemoveAt(index);
			}
			this.preview.Image = null;
			
			this.checkGeneratable();
		}
		
		//
		// 保存するフォルダを選ぶ
		//
		void SaveFolderButtonClick(object sender, System.EventArgs e)
		{
			if (this.albumFolderDialog.ShowDialog() == DialogResult.OK){
				string path = this.albumFolderDialog.SelectedPath;
				if (Directory.Exists(path)){
					this.saveFolderTextBox.Text = path;
				}
			}
		}
		
		private string albumFolderLink = "";
		private string previewLink = "";
		private void changeAlbumFolderLink(){
			//this.albumFolderLink = this.saveFolderTextBox.Text+"\\"+this.albumTitleTextBox.Text;
			this.albumFolderLink = Path.Combine(this.saveFolderTextBox.Text, this.albumTitleTextBox.Text);
			this.albumFolderLinkLabel.Text = this.albumFolderLink;
			
			this.previewLink = Path.Combine(this.albumFolderLink, "index.html");
		}
		
		//
		// サムネイル作成
		//
		private void makeThumbnail(string path, out Bitmap bmp){
			bmp = new Bitmap(path);
			int imgHeight = bmp.Height;
			int imgWidth = bmp.Width;
			int thumbHeight = (int)this.thumbHeightBox.Value;
			
			if (imgHeight>thumbHeight){
				int w = imgWidth * thumbHeight/imgHeight;
				bmp = new Bitmap(bmp, w, thumbHeight);
			}
		}
		/*
		private Bitmap makeThumbnail(string path){
			Bitmap bmp = new Bitmap(path);
			int imgHeight = bmp.Height;
			int imgWidth = bmp.Width;
			int thumbHeight = (int)this.thumbHeightBox.Value;
			
			if (imgHeight>thumbHeight){
				int w = imgWidth * thumbHeight/imgHeight;
				return new Bitmap(bmp, w, thumbHeight);
			} else {
				return bmp;
			}
		}
		*/
		
		//
		// アルバムを生成
		//
		public void generageAlbum(){
			
			// 必要なディレクトリ作成
			this.progressForm.setStatus("ディレクトリ作成中");
			string originalImageFolder = Path.Combine(this.albumFolderLink, "original");
			string thumbImageFolder = Path.Combine(this.albumFolderLink, "thumb");
			Directory.CreateDirectory(this.albumFolderLink);
			if (this.originalImageCheckBox.Checked)
				Directory.CreateDirectory(originalImageFolder);
			Directory.CreateDirectory(thumbImageFolder);
			
			// 必要なファイルをコピー
			this.progressForm.setStatus("必要なファイルを作成中");
			string swfPath = Path.Combine(this.albumFolderLink, "album.swf");
			string appDir = Path.GetDirectoryName(Application.ExecutablePath);
			File.Copy(Path.Combine(appDir, "album.swf"), swfPath, true);
			
			// HTMLを作成
			string htmlPath = Path.Combine(this.albumFolderLink, "index.html");
			FlashHtml html = new FlashHtml();
						
			html.outputHtml(this.albumTitleTextBox.Text,
			                this.colorToHtml(this.bgColorPanel.BackColor),
			                htmlPath);
			
			// コンフィグファイルを作成
			this.outputConfigFile();
			
			string listText = "";
			this.progressForm.setTotalProgressMax(this.imageListBox.Items.Count);
			for (int i=0; i<this.imageListBox.Items.Count; i++){
				ImageFile img = (ImageFile)(this.imageListBox.Items[i]);
				
				this.progressForm.setStatus("サムネイルを作成中 (" +
				                       (i+1)+"/"+this.imageListBox.Items.Count+") "+
				                       img.Name);
				if (File.Exists(img.Path)){
					// オリジナル画像をコピー
					if (this.originalImageCheckBox.Checked) {
						string originalImgPath = Path.Combine(originalImageFolder, img.Name);
						File.Copy(img.Path, originalImgPath, true);
					}
					
					// サムネイル作成・保存
					string thumbImgPath = Path.Combine(thumbImageFolder, img.Name);
					
					//Bitmap bmp = this.makeThumbnail(img.Path);
					Bitmap bmp;
					this.makeThumbnail(img.Path, out bmp);
					
					bmp.Save(thumbImgPath,
					         System.Drawing.Imaging.ImageFormat.Jpeg);
					bmp.Dispose();
					
					// テキストに追加
					if (this.originalImageCheckBox.Checked){
						listText = listText +
									"thumb/" + img.Name + "|"+
									"original/" + img.Name + "\n";
					} else{
						listText = listText + "thumb/" + img.Name + "\n";
					}
				}
				this.progressForm.setTotalProgress(i+1);
			}
			
			// 画像リストをテキストファイル書き込み（Shift JIS）
			this.progressForm.setStatus("画像リストを保存中");
			this.outputImageList(listText);
			
			// プレビューリンク有効に
			this.previewLinkLabel.Enabled = true;
			
			// 完成
			this.progressForm.complete();
		}
		
		private void outputImageList(string listText){
			string txtPath = Path.Combine(this.albumFolderLink, "photo.txt");
			StreamWriter sw = new StreamWriter(txtPath, false, 
			                                   System.Text.Encoding.GetEncoding(932));
			sw.Write(listText);
			sw.Close();
		}
		
		//
		// アルバム作成ボタンクリック
		//
		ProgressForm progressForm = null;
		void GenerateAlbumButtonClick(object sender, System.EventArgs e)
		{
			// プログレスフォーム表示
			this.progressForm = new ProgressForm();
			
			// アルバム生成スレッド
			Thread t = new Thread(new ThreadStart(this.generageAlbum));
			t.Start();
			
			switch(this.progressForm.ShowDialog()){
				case DialogResult.Abort:
					t.Abort();
					break;
				case DialogResult.OK:
					if(this.progressForm.openBrowserCheck())
						this.openAlbum();
					break;
			}
			this.progressForm.Dispose();
		}
		
		//
		// 保存フォルダ変更時
		//
		void SaveFolderTextBoxTextChanged(object sender, System.EventArgs e)
		{
			this.changeAlbumFolderLink();
			this.checkGeneratable();
		}
		
		//
		// タイトル変更時
		//
		void AlbumTitleTextBoxTextChanged(object sender, System.EventArgs e)
		{
			// 使用可能文字文字検証
			TextBox tb = (TextBox)sender;
			String str = tb.Text;
			// 使えない文字
			// \ / : * ? " <> |
			//Regex reg = new Regex(@"[^\w-= #&().%\{\}\+]");
			Regex reg = new Regex("[/:*?\"<>|\\x5c]");
			str = reg.Replace(str, "");
			tb.Text = str;
			
			this.changeAlbumFolderLink();
			this.checkGeneratable();
		}
		
		//
		// 保存フォルダリンククリック時
		//
		void AlbumFolderLinkLabelLinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			// フォルダを開く
			if (Directory.Exists(this.albumFolderLink))
				System.Diagnostics.Process.Start(this.albumFolderLink);
		}
		
		//
		// プレビューリンククリック時
		//
		void PreviewLinkLabelLinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			this.openAlbum();
		}
		
		//
		// アルバムを開く
		//
		private void openAlbum(){
			if (File.Exists(this.previewLink))
				System.Diagnostics.Process.Start(this.previewLink);
		}
		
		//
		// 生成ボタンを押せるか
		//
		private void checkGeneratable() {
			// リストに画像があるか
			// タイトルがあるか
			// ディレクトリがあるか。ディレクトリは正しいか
			if (this.imageListBox.Items.Count>0 &&
			    this.albumTitleTextBox.Text != "" &&
			    this.saveFolderTextBox.Text != "" &&
			    Directory.Exists(this.saveFolderTextBox.Text)) {
				
				this.generateAlbumButton.Enabled = true;
			} else {
				this.generateAlbumButton.Enabled = false;
			}
		}
		
		private void initAlbumConfig() {
			this.thumbHeightBox.Value = 320;
			
			this.imageSizeBox.Value = 80;
			this.imageBorderWidthBox.Value = 8;
			this.bgColorPanel.BackColor = ColorTranslator.FromHtml("#000000");
			this.imageBorderColorPanel.BackColor = ColorTranslator.FromHtml("#FFFFFF");
			this.scrollbarColorPanel.BackColor = ColorTranslator.FromHtml("#FFFFFF");
			this.scrollBorderColorPanel.BackColor = ColorTranslator.FromHtml("#666666");
			this.arrowColorPanel.BackColor = ColorTranslator.FromHtml("#FFFFFF");
		}
		
		private void outputConfigFile() {
			string configPath = Path.Combine(this.albumFolderLink, "config.txt");
			AlbumConfig config = new AlbumConfig();
			
			// 設定
			config.ImageHeightPercent = this.imageSizeBox.Value.ToString();
			config.ImageBorderWidth = this.imageBorderWidthBox.Value.ToString();
			config.BackgroundColor = this.colorToHex(this.bgColorPanel.BackColor);
			config.ImageBorderColor = this.colorToHex(this.imageBorderColorPanel.BackColor);
			config.ScrollBorderColor = this.colorToHex(this.scrollBorderColorPanel.BackColor);
			config.ScrollBarColor = this.colorToHex(this.scrollbarColorPanel.BackColor);
			config.ArrowColor = this.colorToHex(this.arrowColorPanel.BackColor);
			
			// 出力
			config.output(configPath);
		}
		
		//
		// Colorを"0x000000"形式に変換
		//
		private string colorToHex(Color color){
			return string.Format("0x{0:X2}{1:X2}{2:X2}", color.R, color.G, color.B);
		}
		//
		// Colorを"#000000"形式に変換
		//
		private string colorToHtml(Color color) {
			return string.Format("#{0:X2}{1:X2}{2:X2}", color.R, color.G, color.B);
		}
		
		private void ColorPanelClick(object sender, System.EventArgs e)
		{
			Panel panel = (Panel)sender;
			this.colorDialog.Color = panel.BackColor;
			if(this.colorDialog.ShowDialog() == DialogResult.OK){
				panel.BackColor = this.colorDialog.Color;
			}
		}
		
		void Button1Click(object sender, System.EventArgs e)
		{
			this.initAlbumConfig();
		}
		
		//
		// ファイルのドラッグ＆ドロップでファイルを追加
		//
		void MainFormDragDrop(object sender, System.Windows.Forms.DragEventArgs e)
		{
			string[] files = (string[])e.Data.GetData(DataFormats.FileDrop, false);
			
			for (int i=0; i<files.Length; i++){
				if (Directory.Exists(files[i]))
					this.addImageFromDirectory(files[i]);
				else
					this.addImageFile(files[i]);
			}
			this.checkGeneratable();
		}
		
		void MainFormDragEnter(object sender, System.Windows.Forms.DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
				e.Effect = DragDropEffects.All;
			else
				e.Effect = DragDropEffects.None;
		}
		
	}
}
