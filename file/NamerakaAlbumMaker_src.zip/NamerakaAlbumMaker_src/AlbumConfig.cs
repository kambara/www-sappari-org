/*
 * Created by SharpDevelop.
 * User: kambara
 * Date: 2004/11/09
 * Time: 20:39
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.IO;

namespace AlbumMaker
{
	/// <summary>
	/// Description of AlbumConfig.
	/// </summary>
	public class AlbumConfig
	{
		private string imageHeightPercent = "80";
		private string backgroundColor = "0x000000";
		private string imageBorderWidth = "8";
		private string imageBorderColor = "0xFFFFFF";
		private string arrowColor = "0x666666";
		private string scrollBorderColor = "0x666666";
		private string scrollbarColor = "0xFFFFFF";
		
		public AlbumConfig()
		{
		}
		
		public string ImageHeightPercent{
			set {
				this.imageHeightPercent = value;
			}
		}
		public string ImageBorderWidth{
			set {
				this.imageBorderWidth = value;
			}
		}
		public string ImageBorderColor{
			set{
				this.imageBorderColor = value;
			}
		}
		public string BackgroundColor{
			set{
				this.backgroundColor = value;
			}
		}
		public string ScrollBorderColor{
			set{
				this.scrollBorderColor = value;
			}
		}
		public string ScrollBarColor{
			set{
				this.scrollbarColor = value;
			}
		}
		public string ArrowColor{
			set{
				this.arrowColor = value;
			}
		}
		
		public void output(string path){
			// SJISで出力
			StreamWriter sw = new StreamWriter(path, false, 
			                                   System.Text.Encoding.GetEncoding(932));
			sw.Write(this.createConfigText());
			sw.Close();
		}
		
		private string createConfigText(){
			string txt =
				"ImageHeightPercent="+	this.imageHeightPercent +
				"&"+
				"BackgroundColor="+		this.backgroundColor +
				"&"+
				"ImageBorderWidth="+	this.imageBorderWidth +
				"&"+
				"ImageBorderColor="+	this.imageBorderColor +
				"&"+
				"ArrowColor="+			this.arrowColor +
				"&"+
				"ScreenBorderColor="+	this.scrollBorderColor +
				"&"+
				"ScrollbarColor="+		this.scrollbarColor;
			
			return txt;
		}
	}
}
