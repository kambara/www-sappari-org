/*
 * Created by SharpDevelop.
 * User: kambara
 * Date: 2004/11/09
 * Time: 15:48
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.IO;

namespace AlbumMaker
{
	/// <summary>
	/// Description of FlashHtml.
	/// </summary>
	public class FlashHtml
	{
		public FlashHtml()
		{
		}
		
		public void outputHtml(string title,string bgColor ,string path){
			// SJISで出力
			StreamWriter sw = new StreamWriter(path, false, 
			                                   System.Text.Encoding.GetEncoding(932));
			sw.Write(this.createFlashHtmlText(title, bgColor));
			sw.Close();
		}
		
		private string createFlashHtmlText(string title, string bgColor){
			string html = 
			"<HTML>\n" +
			"<HEAD>\n" +
			"<meta http-equiv=Content-Type content=\"text/html; charset=Shift-JIS\">\n"+
			"<TITLE>" + title + "</TITLE>\n"+
			"</HEAD>\n"+
			"<BODY bgcolor="+ bgColor +">\n"+
			"<OBJECT classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0\" WIDTH=100% HEIGHT=100% id=album ALIGN=\"\">\n"+
			"<PARAM NAME=movie VALUE=album.swf>\n"+
			"<PARAM NAME=quality VALUE=high>\n"+
			"<PARAM NAME=bgcolor VALUE="+bgColor+">\n"+
			"<EMBED src=album.swf quality=high bgcolor="+bgColor+" WIDTH=100% HEIGHT=100% NAME=album ALIGN=\"\" TYPE=application/x-shockwave-flash PLUGINSPAGE=http://www.macromedia.com/go/getflashplayer></EMBED>\n"+
			"</OBJECT>\n"+
			"</BODY>\n"+
			"</HTML>\n";
			
			return html;
		}
	}
}
