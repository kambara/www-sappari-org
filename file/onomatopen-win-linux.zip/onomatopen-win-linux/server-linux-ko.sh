#!/bin/sh

JULIAN='grammar-kit-v4.2-linux'
ONOMATOPE='onomatope-ko'
./$JULIAN/bin/julius-4.2 -C $ONOMATOPE/mic.jconf -C $JULIAN/hmm_ptm.jconf -module










