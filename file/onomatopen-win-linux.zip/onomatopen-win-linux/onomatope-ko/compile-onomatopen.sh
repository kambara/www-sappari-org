#!/bin/sh

## Compile after editing .voca and .grammer.
## This script converts them to .dfa, .dict and .term.

../julian-kit-v3.1-linux/bin/mkdfa.pl onomatope
